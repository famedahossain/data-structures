//Fameda Hossain Lab Time Fri @ 12pm
import java.util.HashSet;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Read in the value of k
        int k = Integer.parseInt(sc.nextLine());
        
        // Read in the value of n
        int n = Integer.parseInt(sc.nextLine());
        
        // Read in the list of numbers
        int[] numbers = new int[n];
        String input = sc.nextLine();
        if (input.equals("")) {
            numbers = new int[0];
        } else {    
            String[] numberStrings = input.split(" ");
            for (int i = 0; i < n; i++) {
                numbers[i] = Integer.parseInt(numberStrings[i]);
            }
        }
        
        System.out.println(findPairs(numbers, k));
    }
    
    private static int findPairs(int[] numbers, int k) {
        HashSet<Integer> values = new HashSet<Integer>();
        
        for(int i = 0; i<numbers.length; i++){
          values.add(numbers[i]); // add numbers from the array to the HashSet
        }
        
        int numberOfPairs = 0;

        for(int i = 0; i<numbers.length; i++){
            if (values.contains(k-(numbers[i]))) { //checks if there is another value that adds up to k
              numberOfPairs+=1; //if true counter +1 each time
            }

        }
        
        return numberOfPairs/2; //divide the counter by 2 so as to not get duplicate pairs
        
    }
    
}