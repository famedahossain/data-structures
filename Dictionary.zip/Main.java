//Fameda Hossain Lab Time Fri @12pm
import java.lang.UnsupportedOperationException;
import java.util.Scanner;

public class Main {
    // Constants for function names in input
    public static final String MIN_METHOD_NAME = "MIN";
    public static final String MAX_METHOD_NAME = "MAX";
    public static final String RANGE_METHOD_NAME = "RANGE";
    public static final String AVERAGE_METHOD_NAME = "AVERAGE";
    public static final String MODE_METHOD_NAME = "MODE";
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Read in the method name that we want to call
        String methodName = sc.nextLine();
        
        // Read in number of words
        int numWords = Integer.parseInt(sc.nextLine());
        
        // Read in list of words
        String[] words = new String[numWords];
        for (int i = 0; i < numWords; i++) {
            words[i] = sc.nextLine();
        }
        
        // Run the specified method
        switch (methodName) {
            case MIN_METHOD_NAME:
                System.out.println(minWordLength(words));
                break;
            case MAX_METHOD_NAME:
                System.out.println(maxWordLength(words));
                break;
            case RANGE_METHOD_NAME:
                System.out.println(wordLengthRange(words));
                break;
            case AVERAGE_METHOD_NAME:
                System.out.println(averageWordLength(words));
                break;
            case MODE_METHOD_NAME:
                System.out.println(mostCommonWordLength(words));
                break;
            default:
                throw new UnsupportedOperationException();               
        }
    }
                                   
    private static int minWordLength(String[] words) {
        int min = words[0].length(); //Sets the minimum word length to the length of the first element
        for(int i=1; i<words.length; i++){ 
          if (words[i].length() < min) { // Checks to see if the next element word length is less than the min word length
            min = words[i].length(); // If this is the case, reassign min word length
          }
        }
        return min; 
    }
                                   
    private static int maxWordLength(String[] words) {
        int max = words[0].length(); //Sets the maximum word length to the length of the first element
        for(int i=1; i<words.length; i++){ 
          if (words[i].length() > max) { // Checks to see if the next element word length is greater than the max word length
            max = words[i].length(); // If this is the case, reassign max word length
          }
        } return max;
    }
                                   
    private static int wordLengthRange(String[] words) {
        int max = maxWordLength(words); // Calls the method maxWordLength for the input array words and the result is stored as max
        int min = minWordLength(words); // Calls the method minWordLength for the input array words and the result is stored as min
        return max-min; // Finds the range 
    }
                                   
    private static String averageWordLength(String[] words) {
        double sum = 0;
        for(int i = 0; i<words.length; i++){
          sum = words[i].length() + sum; // Finds the word length of each element and continuously adds it to the overall sum
        }
        double average = (sum/words.length);
        return String.format("%.2f", average); // Formats the average to be accurate to two decimal places
    }
                                   
    private static int mostCommonWordLength(String[] words) {
        int[] holdsRangeArray = new int[101]; // Represents an array with 100 elements 
        int value;
         for(int i = 0; i<words.length; i++){
           value = words[i].length(); // Finds the length of a word at index i and stores it in the variable value 
           holdsRangeArray[value]+=1; // Everytime we get a word with a specific length(value), we add 1 to the index of that specific word length
         }
         
         int max = 0;
         int secondMax = 0;
         for(int i=1; i<101; i++){
           if (holdsRangeArray[i] >= holdsRangeArray[max]){ // We check our array to see where our highest frequency is
             secondMax = max; // This statement allows us to find the second highest frequency
             max = i; // The max is set to i which is where our highest frequency is located
           }
         }
         
         if (holdsRangeArray[secondMax] == holdsRangeArray[max]) { // If we have a tie (same frequency for secondMax and max)
           return -1; // We must return -1
         }
         
         return max;  // Returns most common word length
        
        }
    }
