public class MyHashSet {
  private Object[] dictionary;
  public MyHashSetNode first;
  public MyHashSetNode last;
  public int size;

  public MyHashSet() {
   dictionary = new Object[2000];
  }
  
   public void add(String value) {
   if(dictionary[this.hashCode(value)] == null) {
     dictionary[this.hashCode(value)] = value;
   }
   
   else {
     String[] secondaryString = new String[3];
     secondaryString[0] = (String)dictionary[this.hashCode(value)];
     secondaryString[1] = value;
   }
   
 }
 
 public int hashCode(String x) {
   return (((x.hashCode() % 2000) < 0) ? (-1*(x.hashCode() % 2000)) : (x.hashCode() % 2000));
 }

  public boolean contains(String it) {
   if(dictionary[this.hashCode(it)] instanceof Object[]) {
     String[] insideArray = (String[])(dictionary[this.hashCode(it)]);
     for (Object o : insideArray) {
       if (((String)o).equals(it)) return true;
     }
     return false;
   }
   if(dictionary[this.hashCode(it)] != null && dictionary[this.hashCode(it)].equals(it)) {
     return true;
   }
   else {
     return false;
   }
   
 }

}