public class MyHashSetNode {
  public MyHashSetNode next;
  public MyHashSetNode prev;
  public String val;

  public MyHashSetNode(String val) {
    this.val = val;
  }

  @Override
  public boolean equals(Object other) {
    if(!(other instanceof MyHashSetNode)) {
      return false;
    }
    MyHashSetNode otherNode = (MyHashSetNode) other;
    return this.val.equals(otherNode.val);
  }

  // Don't need getters and setters since all the fields are public

}