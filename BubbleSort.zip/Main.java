import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Read in the list of numbers
        int[] numbers;
        String input = sc.nextLine();
        if (input.equals("")) {
            numbers = new int[0];
        } else {    
            String[] numberStrings = input.split(" ");
            numbers = new int[numberStrings.length];
            for (int i = 0; i < numberStrings.length; i++) {
                numbers[i] = Integer.parseInt(numberStrings[i]);
            }
        }

        // Sort the list
        bubbleSort(numbers);

        // Print the sorted list
        StringBuilder resultSb = new StringBuilder();
        for (int i = 0; i < numbers.length; i++) {
            resultSb.append(new Integer(numbers[i]).toString());
            if (i < numbers.length - 1) {
                resultSb.append(" ");
            }
        }
        System.out.println(resultSb.toString());
    }
    
    public static void bubbleSort(int[] numbers) {
      for(int i = 0; i <numbers.length; i++) {
        int swap = 0;
			  for(int j = 0; j<numbers.length-1; j++) {
				  if (numbers[j] > numbers[j+1]) {
					  int temp = numbers[j];
					  numbers[j] = numbers[j+1];
					  numbers[j+1] = temp;
					  swap++;
				  }
				  else if (swap == 0){
				    return;
				  }
			  }
		  }
    }
    
}