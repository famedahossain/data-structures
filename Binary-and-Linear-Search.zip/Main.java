//Fameda Hossain Lab Time Fri @12pm
class Main {
  public static void main(String[] args) {
    // Don't mess with this
  }
}

class LinearSearch { 
  public int linearSearch(int[] inputArray, int searchTarget) {
    for(int i=0; i<inputArray.length; i++) {
      if(inputArray[i] == searchTarget){ // If the value at the given index matches the searchTarget, return the index 
        return i;
      }
    }
    return -1; //If the value is not found, return -1
  }
}

class BinarySearch { 
  public int binarySearch(int[] sortedArray, int searchTarget) {
    int start = 0; 
    int end = sortedArray.length-1;
    
    while(start <= end) {
      int middle = (start+end)/2; //To calculate our guess we must take the average of the start plus the end index
      
      if(sortedArray[middle] == searchTarget){ //If the value at the middle index equals our searchTarget, return the middle index
        return middle;
      } 
      
      else if(sortedArray[middle] < searchTarget){ // If the value at the middle index is less than our searchTarget, we must shift our start to our middle+1
        start = middle+1;
      }
      
      else{ // If the value at the middle index is greater than our searchTarget, we must shift our end to our middle-1
        end = middle-1;
      }
    }

    return -1; //If we do not find our searchTarget in the sortedArray, return -1
  }
}

