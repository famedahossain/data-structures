// Fameda Hossain Lab Time Fri. @ 12pm
import java.util.*;
public class Main {
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
		
		System.out.print("What is your name? ");
		String name = input.nextLine(); // Variable that represents user's inputed name
		
		
		while (name.isEmpty()) { // While the user does not input a name, continue to prompt them for a name 
			System.out.print("Please enter your name: ");
			name = input.nextLine(); // User must enter in their name
		}
	
		System.out.println("Hello, " + name + "!"); 
		
    }
}