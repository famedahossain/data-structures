// Fameda Hossain Lab Time @ 12pm
import java.util.*;
class Main {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter n: ");
		int n = input.nextInt(); // Integer variable represents the number of numbers, from 0 to n
		
		while (n < 1) { // While n is negative or equal to 0, prompt for a postive integer n
			System.out.print("Enter a positive integer for n: ");
			n = input.nextInt();
		}
		
		int nMinusOne = n-1; // Integer variable represents the number of numbers, from 0 to n-1
		int start = 0; // Integer variable initialized to 0 represents the first number
		int end = nMinusOne; // Integer variable set to nMinusOne represents the last number
		
		System.out.println("Welcome to Guess My Number!");
		System.out.println("Please think of a number between 0 and " + nMinusOne + ".");
		
		String response = "H"; // String Variable initialized to "H" to be used in the condition of the while loop
		
		
		while(!response.equals("C")) { // While the user response does not equal "C", continue with the following statements
			int ourGuess = (int)(Math.ceil(((start+end)/2.0))); // Integer variable represents the guess. It is the addition of the start and end variable divided by 2.0, then taken as a ceiling and lastly type casted as an integer.
			System.out.println("Is your number: " + ourGuess + "?");
			System.out.println("Please enter C for correct, H for too high, or L for too low. ");
			System.out.print("Enter your response (H/L/C): ");
			response = input.next(); // User enters whether the guess was too High, too Low, or Correct
			
			while (!response.equals("H") && !response.equals("C") && !response.equals("L")) { // If the user response is not equal to "H", "L", or "C", prompt them until the response equals one of those choices.
				System.out.print("Enter your response (H/L/C): ");
				response = input.next();
			}
			
			
			if(response.equals("L")) { // If the guess is too Low, start becomes ourGuess+1
				start = ourGuess+1;
			}
			
			else if (response.equals("H")) { //If the guess is too High, end becomes ourGuess-1
				end = ourGuess-1;
			}
			
			
		}
		
			System.out.println("Thank you for playing Guess My Number!");
			
	}

}
