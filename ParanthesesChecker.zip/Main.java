import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Read the input string
        String input = sc.nextLine();
        
        BalancedParentheses bp = new BalancedParentheses();
        // Print whether the string has balanced parentheses
        System.out.println(bp.hasBalancedParentheses(input));
    }
}

class BalancedParentheses {
    public boolean hasBalancedParentheses(String input) {
      int count1 = 0;
      int count2 = 0;
      
      if(input.length() > 0 && input.charAt(0) == ')'){
        return false;
      }
      
      for(int i = 0; i<input.length(); i++){
        if(input.charAt(i) == '('){
          count1++;
        }
        if(input.charAt(i) == ')'){
          count2++;
        }
      }
      
      return (count1 == count2);
    
  }
}