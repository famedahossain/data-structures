import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Read in the list of numbers
        int[] numbers;
        String input = sc.nextLine();
        if (input.equals("")) {
            numbers = new int[0];
        } else {    
            String[] numberStrings = input.split(" ");
            numbers = new int[numberStrings.length];
            for (int i = 0; i < numberStrings.length; i++) {
                numbers[i] = Integer.parseInt(numberStrings[i]);
            }
        }
        
        // Reverse the list
        int[] resultArray = reverseArray(numbers);
        
        // Print the reversed list
        StringBuilder resultSb = new StringBuilder();
        for (int i = 0; i < resultArray.length; i++) {
            resultSb.append(new Integer(resultArray[i]).toString());
            if (i < resultArray.length - 1) {
                resultSb.append(" ");
            }
        }
        System.out.println(resultSb.toString());
    }
    
    public static int[] reverseArray(int[] originalArray) {
        for(int i=0; i<originalArray.length/2; i++){
          int temp = originalArray[i];
          originalArray[i] = originalArray[originalArray.length-1-i];
          originalArray[originalArray.length-1-i] = temp;
        }
        
        return originalArray;
    }
}