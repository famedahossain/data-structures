import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // parse the array representing the binary search tree
        int[] binaryTree;
        String input = sc.nextLine();
        if (input.equals("")) {
            binaryTree = new int[0];
        } else {    
            String[] binaryTreeStrings = input.split(" ");
            binaryTree = new int[binaryTreeStrings.length];
            for (int i = 0; i < binaryTreeStrings.length; i++) {
                binaryTree[i] = Integer.parseInt(binaryTreeStrings[i]);
            }
        }

        // check if this is a binary search tree; print the result
        System.out.println(isBinarySearchTree(binaryTree));
    }
    
    public static boolean isBinarySearchTree(int[] binaryTree) {
        if(binaryTree.length == 1) {
          return true;
        }
        int counter = 0;
        
        for(int i = 0; i<binaryTree.length; i++){
          int left = (i*2)+1;
          int right = (i*2)+2;
          if(left < binaryTree.length && binaryTree[i] > binaryTree[left]){
            counter++;
          
          if(right < binaryTree.length && binaryTree[i] < binaryTree[right]) {
            counter++;
          }
          else if(left == binaryTree.length-1){
            counter=counter*2;
            i=i*2+1;
          }
          else{
            return false;
          }
          }
          else{
            if(left < binaryTree.length){
              if(binaryTree[i]<binaryTree[left]){
                return false;
              }
            }
            else if(left == binaryTree.length) {
              i=i*2+1;
            }
          }
        }
        int index = counter/2;
        int levelCurrent = power((2%index)+1);
        for(int i = index; i < binaryTree.length; i++){
          if(i<(index+(levelCurrent/2))) {
            if(binaryTree[i]>binaryTree[0]) {
              return false;
            }
          }
          else{
            if(binaryTree[i]<binaryTree[0]){
              return false;
            }
          }
        }
        return true;
    }
    
    public static int power(int x){
      int y = 1;
      for(int i = x; i > 0; i--){
        y*=2;
      }
      return y;
    }
    
}