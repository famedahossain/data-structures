/**
 * This class represents a linked list node (i.e. an object
 * containing an element and its next and previous
 * objects in the list) 
 */
public class MyLinkedListNode {
    private int value = 0;
    private MyLinkedListNode prev = null;
    private MyLinkedListNode next = null;
    
    public MyLinkedListNode(int value, MyLinkedListNode prev, MyLinkedListNode next) {
        this.value = value;
        this.prev = prev;
        this.next = next;
    }
    
    public MyLinkedListNode getNext() {
        return this.next;
    }
    
    public void setNext(MyLinkedListNode next) {
        this.next = next;
    }
    
    public MyLinkedListNode getPrev() {
      return this.prev;
    }
    
    public void setPrev(MyLinkedListNode prev) {
        this.prev = prev;
    }
    
    @Override
    public String toString() {
        return (new Integer(this.value)).toString();
    }
}