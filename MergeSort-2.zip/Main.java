import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // get number of lines
        int n = Integer.parseInt(sc.nextLine());
        
        // for each line, create an ExecutiveAssistant object
        ExecutiveAssistant[] candidates = new ExecutiveAssistant[n];
        for (int i = 0; i < n; i++) {
            // Parse a list of properties
            String line = sc.nextLine();
            String[] properties = line.split(" ");
                
            // add a new ExecutiveAssistant to the array
            candidates[i] = new ExecutiveAssistant(
                /* firstName */ properties[0],
                /* lastName */ properties[1],
                /* organizationScore */ Integer.parseInt(properties[2]),
                /* punctualityScore */ Integer.parseInt(properties[3])
            );
        }
        
        // sort the ExecutiveAssistant objects
        mergeSort(candidates, 0, candidates.length-1);
        
        // print the candidate names
        for (int i = 0; i < n; i++) {
            System.out.println(candidates[i]);
        }
    }
    
    private static void mergeSort(ExecutiveAssistant[] candidates, int start, int end) {
        if(start >= end){
          return;
        }
        
        int mid = (start+end)/2;
        
        mergeSort(candidates, start, mid);
        mergeSort(candidates, mid+1, end);
        
        merge(candidates, start, mid, end);
    }
    
    public static void merge(ExecutiveAssistant[] candidates, int start, int mid, int end){
      ExecutiveAssistant[] firstHalf = new ExecutiveAssistant[mid-start+1];
      ExecutiveAssistant[] secondHalf = new ExecutiveAssistant[end-mid];
      
      for(int i= start; i<=mid; i++){
        firstHalf[i-start] = candidates[i];
      }
      
      for(int i= mid+1; i<=end; i++){
        secondHalf[i-mid-1] = candidates[i];
      }
      
      int firstHalfPointer = 0;
      int secondHalfPointer = 0;
      
      for(int i = start; i<=end; i++){
        if(firstHalfPointer >= firstHalf.length){
          candidates[i] = secondHalf[secondHalfPointer];
          secondHalfPointer++;
          continue;
        }
        if(secondHalfPointer >= secondHalf.length){
          candidates[i] = firstHalf[firstHalfPointer];
          firstHalfPointer++;
          continue;
        }
        if(firstHalf[firstHalfPointer].getSutability() >= secondHalf[secondHalfPointer].getSutability()){
          candidates[i] = firstHalf[firstHalfPointer];
          firstHalfPointer++;
        }
        else{
          candidates[i] = secondHalf[secondHalfPointer];
          secondHalfPointer++;
        }
      }
    }
}
