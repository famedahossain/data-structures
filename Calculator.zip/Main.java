import java.util.Scanner;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // read input
        String expression = sc.nextLine();
        
        // print the evaluated result
        System.out.println(eval(expression));
    }
    
	public static int eval(String expression) {
        Stack<Character> operators = new Stack<Character>();
        Stack<Integer> values = new Stack<Integer>();
        
        for(int i = 0; i < expression.length() ; i++){
        	char myChar = expression.charAt(i); 
        	
          if(myChar == '+' || myChar == '*'||myChar == '(') {
        	  operators.push(myChar);
          }
          
          else if(myChar == ')' ) {
        	  while(operators.peek() != '(' ) {
        		  if(operators.get(operators.size()-2) == '(') {
        			  values.push(arithmeticSolver(values.pop(),values.pop(),operators.pop()));
        		  }
        		  else {
        			  for(int j = operators.size()-1; j > 0;j--) {
        				  if(operators.get(j) == '(') {
        					  j = 0;
        				  }
        				  else if(operators.get(j) == '*') {
        					  values.add(j-1,arithmeticSolver(values.remove(j-1),values.remove(j-1),operators.remove(j)));
        				  }
        			  }
        			  values.push(values.pop()+values.pop());
            		  operators.pop();
        		  }
        	  }
        	  operators.pop();
          }
          else {
        	  values.push(Character.getNumericValue(myChar));
        	 
        	  if(values.size() > 1) {
        		  if(Character.isDigit(expression.charAt(i-1))){
            		  String prev = Integer.toString(values.pop());
            		  String first = Integer.toString(values.pop());;
            		  values.push(Integer.parseInt(toString(first,prev)));
            	  }
        	  }
        	  if(!operators.isEmpty()) {
        		  if(operators.peek() == '*') {
        			  if(i == expression.length()-1) {
        				  continue;
        			  }
        			  else if(!Character.isDigit((expression.charAt(i+1)))) {
                		  values.push(arithmeticSolver(values.pop(),values.pop(),operators.pop()));
                	  }
            	  }
        	  }

          }
        }

        if(!operators.isEmpty()) {
        	while(operators.contains('*')) {
        		for(int i = 0;i < operators.size();i++) {
        			if(operators.get(i) == '*') {
        				operators.remove(i);
        				values.add(i,values.remove(i) * values.remove(i));
        				System.out.println(values.toString());
        				System.out.println(operators.toString());
        			}
        		}
        	}
        	while(operators.contains('+')) {
        		values.push(arithmeticSolver(values.pop(),values.pop(),operators.pop()));
        	}
        }
        
        return values.pop();
    }

	public static String toString(String x, String y) {
		return x + y;
	}
	
	public static int arithmeticSolver(int num1, int num2,char operator) {
    	if(operator == '*') {
    		return num1 * num2;
    	}
    	else if(operator == '+') {
    		return num1 + num2;
    	}
    	return 0;
    }
}