// Fameda Hossain Lab Time Fri @ 12 pm
import java.lang.UnsupportedOperationException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // parse the number of strings
        int numStrings = Integer.parseInt(sc.nextLine());
        
        // parse each string
        String[] stringsArray = new String[numStrings];
        for (int i = 0; i < numStrings; i++) {
            stringsArray[i] = sc.nextLine();
        }
        
        // print whether there are duplicates
        System.out.println(hasDuplicates(stringsArray));
    }
    
    private static boolean hasDuplicates(String[] stringsArray) {
        for (int i = 0; i < stringsArray.length; i++){
          for(int j = i+1; j < stringsArray.length; j++) { // We do a nested for loop to compare each element to the next subsequent elements 
            if(stringsArray[i].equals(stringsArray[j])) { // If the elements are equivalent
            return true; // There are duplicates
          }
        }
      }
       return false;
    }
}