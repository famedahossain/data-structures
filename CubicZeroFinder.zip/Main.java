import java.util.*;
 
public class Main {
 
   private static final double EPSILON = 0.00001;
 
   public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
 
       // Read in a, b, c, and d for our
       // equation ax^3 + bx^2 + cx + d = 0
       int a = Integer.parseInt(sc.nextLine());
       int b = Integer.parseInt(sc.nextLine());
       int c = Integer.parseInt(sc.nextLine());
       int d = Integer.parseInt(sc.nextLine());
 
       // Find the zeroes
       String[] zeroes = findZeroes(a, b, c, d);
 
       // Print the zeroes, one per line
       for (int i = 0; i < zeroes.length; i++) {
           System.out.println(zeroes[i]);
       }
   }
 
   /**
    * Given a, b, c, and d for a cubic equation
    * ax^3 + bx^2 + cx + d = 0,
    * returns a sorted list of zeroes of
    * this cubic equation.
    */
   public static String[] findZeroes(int a, int b, int c, int d) {
       Double[] criticalNumbers = quadraticFormula(3*a,2*b,c);
 
       Double min = null,max = null,inflection = null;
       for(int i=0; i<2; i++){
           if (secondDerivative(a,b,criticalNumbers[i]) < 0) {
               max = criticalNumbers[i];
           }
           else if(secondDerivative(a,b,criticalNumbers[i]) > 0){
               min = criticalNumbers[i];
           }
           if(isAlmostEqual(secondDerivative(a,b,criticalNumbers[i]),0d)){
               inflection = criticalNumbers[i];
           }
       }
 
       boolean reversed = (eval(a,b,c,d,-100) > 0);
 
       if(inflection != null && isAlmostEqual(eval(a,b,c,d,inflection),0d) ){
           System.out.println("Triple Zero");
           String[] results = new String[] {String.format("%.5f",inflection), String.format("%.5f",inflection), String.format("%.5f",inflection)};
           Arrays.sort(results);
           return results;
       }
 
       else if(max != null && isAlmostEqual(eval(a,b,c,d,max),0d) ){
           //Double zero at max
 
           Double uniqueZero = null;
 
           if(reversed){
               uniqueZero = binarySearch(a,b,c,d,-100,min,true);
           }
           else{
               uniqueZero = binarySearch(a,b,c,d,min,100,false);
           }
 
           String[] results =  new String[] {String.format("%.5f",max), String.format("%.5f",max), String.format("%.5f", uniqueZero)};
           Arrays.sort(results);
           return results;
       }
 
       else if(min!= null && isAlmostEqual(eval(a,b,c,d,min),0d) ){
           //Double Zero at min
           Double uniqueZero = null;
 
           if(reversed){
               uniqueZero = binarySearch(a,b,c,d,max,100,true);
           }
           else{
               uniqueZero = binarySearch(a,b,c,d,-100,max,false);
           }
 
           String[] results = new String[] {String.format("%.5f",min), String.format("%.5f",min), String.format("%.5f", uniqueZero)};
           Arrays.sort(results);
           return results;
       }
       else if ((min != null && max != null) &&
               ((eval(a, b, c, d, max) > 0 && eval(a, b, c, d, min) < 0) ||
                       (eval(a, b, c, d, max)< 0 && eval(a, b, c, d, min) > 0))) {
           String[] results = new String[3];
           if (min > max) {
               //when not reversed
               System.out.println(binarySearch(a,b,c,d,max,min, true));
               Double rootZero = 0.0 + binarySearch(a, b, c, d, max, min, true);
               results[0] = String.format("%.5f", rootZero);
               results[1] = String.format("%.5f", binarySearch(a, b, c, d, min, 100, false));
               results[2] = String.format("%.5f", binarySearch(a, b, c, d, -100, max, false));
               Arrays.sort(results);
               return results;
           } else if (min < max) {
               //when reversed
               results[0] = String.format("%.5f", binarySearch(a, b, c, d, min, max, true));
               results[1] = String.format("%.5f", binarySearch(a, b, c, d, max, 100, true));
               results[2] = String.format("%.5f", binarySearch(a, b, c, d, -100, max, true));
               Arrays.sort(results);
               return results;
           }
       }
       return new String[] {"0", "0", "0"};
   }
 
   public static Double secondDerivative(double a, double b, double x){
       Double secondDerivative = (6*a*x)+(2*b);
       return secondDerivative;
   }
 
   public static Double[] quadraticFormula(double a, double b, double c){
       
       Double[] results = new Double[2];
       double discriminant = (b*b) - (4*a*c);
       if (discriminant < 0) return results;
 
       results[0] = (-b - nthRoot(discriminant, 2, 5))/(2*a);
       results[1] = (-b + nthRoot(discriminant, 2, 5))/(2*a);
 
       System.out.println(Arrays.toString(results));
 
       return results;
 
   }
 
   public static Double eval(double a, double b, double c, double d, double x) {
       Double number = ((a)*(pow(x,3)) + (b)*(pow(x,2)) + (c*x) + d);
       return number;
   }
 
   public static Double pow(double a, double k){
       double powered = 1;
       for(int i = 1; i<=k; i++){
           powered *= a;
       }
       return powered;
   }
 
 
   public static Double nthRoot(double number, double n, double precision){
       Double guess = (number / n);
 
       
       while (getDifference(pow(guess, n), number) >= EPSILON) {
           
           Double deltaGuess = (1 / n) * ((number / pow(guess, n - 1)) - guess);
           guess += deltaGuess;
       }
       System.out.println(guess);
       return guess;
   }
 
   
   private static Double getDifference(double number, double otherNumber) {
       return (otherNumber < number) ? (number - otherNumber) : (otherNumber - number);
   }
 
   public static boolean isAlmostEqual(Double x, Double y){
       return (x > y) ? (x-y) <= EPSILON : (y-x) <= EPSILON;
   }
 
   public static Double binarySearch(double a, double b, double c, double d, double lowerBound, double upperBound, boolean reversed){
       double guess = 0d;
 
       while (lowerBound <= upperBound) {
 
           guess = (upperBound + lowerBound) / 2d;
 
           double evaluatedFunction = eval(a, b, c, d, guess);
 
           if (reversed) {
 
               if (getDifference(evaluatedFunction, 0) < EPSILON) return (0.0 + guess);
 
               else if (evaluatedFunction > 0) lowerBound = guess;
 
               else if (evaluatedFunction < 0) upperBound = guess;
 
               else throw new UnsupportedOperationException();
 
           } else {
 
               if (getDifference(evaluatedFunction, 0) < EPSILON) return (0.0 + guess);
 
               else if (evaluatedFunction > 0) upperBound = guess;
 
               else if (evaluatedFunction < 0) lowerBound = guess;
 
               else throw new UnsupportedOperationException();
 
           }
 
       }
       return null;
   }
}
 
 
