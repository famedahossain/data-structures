import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // read input number (which will be between 2 and 1000)
        int number = Integer.parseInt(sc.nextLine());
        // factor the number into an array of prime factors
        int[] factors = factorize(number);

        
        // print array of factors
        for (int i = 0; i < factors.length; i++) {
            System.out.print(factors[i]);
            if (i != factors.length - 1) {
                System.out.print(" ");
            }
        }
        System.out.println();
    }
    
    public static int[] factorize(int number){
      int[] factors = {number};
      
      if(isPrime(number)){
        return factors;
      }
      
      int factor = 2;
      
      while(factor<number){
        if(isPrime(factor) && (number%factor) == 0){
          number /= factor;
          
          int[] temp = factorize(number);
          
          factors = new int[temp.length+1];
          factors[0] = factor;
          for(int i = 1; i<factors.length; i++){
            factors[i] = temp[i-1];
          }
          break;
        }
        factor++;
      }
      return factors;
    }
    
    
    
    public static boolean isPrime(int number){
      if(number == 2){
        return true;
      }
      for(int i=2; i<number; i++){
        if(number%i == 0){
          return false;  
        }
      } return true;
    }
    
}