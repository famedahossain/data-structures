
//Fameda Hossain Lab Time Fri @12pm
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Read n (for taking the nth root)
        int n = Integer.parseInt(sc.nextLine());
        
        // Read number to take the nth root of
        int number = Integer.parseInt(sc.nextLine());
        
        // Read the desired precision
        int precision = Integer.parseInt(sc.nextLine());
    
        // Print the answer
        System.out.println(findNthRoot(number, n, precision));
    }
    
    private static String findNthRoot(int number, int n, int precision) {
        double start = 0;
        double end = number;
        
        while (start<end){
          double middle = (start+end)/2; // Calculates our guess by taking the average of our start plus our end number
          
          double middleExponent = 1;
          for(int i = 1; i<=n; i++){
             middleExponent *= middle; // This for loop allows us to find what our guess to the nth power is 
          }
          
          if((String.format("%." + precision + "f", middleExponent).equals(String.format("%." + precision + "f",(double) number)))) { //If our guess to the nth power (formated to the users desired precision) equals our number (formated to the users desired precision)
            return String.format("%."+precision+"f",middle); // Then return our guess accurate to the users desired precision
          }
          
          else if (middleExponent < number) { // If the guess to the nth power is less than our number, shift start to the guess
            start = middle;
          }
          
          else { // If the guess to the nth power is greater than our number, shift end to the guess
            end = middle;
          }
        }
        
        return "Error";
    }
}