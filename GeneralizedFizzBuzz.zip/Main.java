// Fameda Hossain Lab Time Fri. @ 12pm
import java.util.*;
class Main {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
		
		System.out.print("Enter n: ");
		int n = input.nextInt(); // Integer variable representing a number of numbers, from 1 to n
		
		while(n<1) { // While n is negative or equal to 0, prompt for a positive integer for n
			System.out.print("Enter a positive integer for n: ");
			n = input.nextInt();
		}
		
		System.out.print("Enter p: ");
		int p = input.nextInt(); // Integer variable p
		
		while(p<1) { // While p is negative or equal to 0, prompt for a positive integer for p
			System.out.print("Enter a positive integer for p: ");
			p = input.nextInt();
		}
		
		System.out.print("Enter q: ");
		int q = input.nextInt(); // Integer variable q
		
		while(q<1) { // While q is negative or equal to 0, prompt for a positive integer for q
			System.out.print("Enter a positive integer for q: ");
			q = input.nextInt();
		}
		
		for(int i=1; i<=n; i++) { // For i to n, do the following statements
			if (i%p == 0 && i%q == 0) { // If i mod p is 0 AND i mod q is 0, p AND q are multiples of i, so print FIZZBUZZ
				System.out.println("FIZZBUZZ");
			}
			else if (i%q == 0) { // If only i mod q is 0, then only q is a multiple of i, so print BUZZ
				System.out.println("BUZZ");
			}
			else if (i%p == 0) { // If only i mod p is 0, then only p is a multiple of i, so print FIZZ
				System.out.println("FIZZ");
			}
			else { // If i is not a multiple of either p and or q, print i
				System.out.println(i);
			}
			
		}
  }
}